var db;

 db = new PouchDB("profile_db");


 function AddUser()
 {


    var email =document.getElementById("email").value;
     var age= document.getElementById("age").value;
     var birth= document.getElementById("birth").value;
     var nationality= document.getElementById("nationality").value;
     var address= document.getElementById("address").value;
     var phonenumber= document.getElementById("phonenumber").value;
     var doctor= document.getElementById("doctor").value;

     var User = {

         _id: new Date().toISOString(),
         email: email,
         age: age,
         birth: birth,
         nationality:nationality,
         address:address,
         phonenumber:phonenumber,
         doctor:doctor

     };


     db.put(User,function callback(err,result)
     {
         if (!err)
         {
             console.log('Successfully saved an profile');
             alert ("Profile added!");
         }
     });

   }

     function showProfile()
 {
     db.allDocs({include_docs:true},function(err,docs)
         {
             if (err)
             {
                 return console.log(err);
             }
             else
             {
                var num_records=docs.total_rows;
                 var display_records="";
                 for(var i = 0; i < num_records; i++)
                 {
                         display_records= display_records +  "Email: "+ docs.rows[i].doc.email + "<br/>" +
                         "Age: " + docs.rows[i].doc.age + "<br/>" + "Date of Birth: " + docs.rows[i].doc.birth + "<br/>"+ "Nationality: "+docs.rows[i].doc.nationality+"<br/>"+ 
                         "Address: "+docs.rows[i].doc.address+ "<br/>" + "Phone number: " + docs.rows[i].doc.phonenumber+  "<br/>" + "Doctor: "+docs.rows[i].doc.doctor+ "<hr/>";
                 }
                 document.getElementById("profile_list").innerHTML = display_records;
               }

           });

 }
//End of Account code//



//Start of Pills code//
    var db;
    db = new PouchDB("pills_db");


 function addPills()
 {
     var pill= document.getElementById("pill").value;
     var dosage= document.getElementById("dosage").value;
     var quantity = document.getElementById("quantity").value;
     var frequency = document.getElementById("frequency").value;
     var dose = document.getElementById("dose").value;



     var Pills ={
         _id: new Date().toISOString(),
         pill: pill,
         Dosage: dosage,
         Quantity: quantity,
         Frequency: frequency,
         Dose: dose,


     };
     db.put(Pills,function callback(err,result)
     {
         if (!err)
         {
             console.log('Sucessfully saved Medication');
             alert("Medication saved!");
         }
     });
    }


    function showPills()
    {
        db.allDocs({include_docs:true},function(err,docs)
            {
                if (err)
                {
                    return console.log(err);
                }
                else
                {
                   var num_records=docs.total_rows;
                    var display_records="";
                    for(var i = 0; i < num_records; i++)
                    {
                           
                      display_records= display_records +"Name: " + docs.rows[i].doc.pill + "<br/>" + "Dose: "
                            +docs.rows[i].doc.Dose + docs.rows[i].doc.Quantity+ "<br/>" + "Dosage: " + docs.rows[i].doc.Dosage + "<br/>" + "Frequency: " + docs.rows[i].doc.Frequency+ "<hr/>";
                      
                      }
                    document.getElementById("Pills_list").innerHTML = display_records;
                  }

              });

    }

//End of Pills code//






    function signUp()
    {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        var email = document.getElementById("email").value;



        localStorage.setItem("username",username);
        localStorage.setItem("password",password);
         localStorage.setItem("email",email);

        alert("Profile Saved");
    }

    function Login()
    {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;



        localStorage.setItem("username",username);
        localStorage.setItem("password",password);


        alert("Logged in!");
    }

    function openNav() {
        document.getElementById("mySidebar").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
      }

      /* Set the width of the sidebar to 0 and the left margin of the page content to 0 */
      function closeNav() {
        document.getElementById("mySidebar").style.width = "0";
        document.getElementById("main").style.marginLeft = "0";
      }



      const display = document.getElementById('clock');






function store() {

  var name = document.getElementById('name');
  var pw = document.getElementById('pw');
  var lowerCaseLetters = /[a-z]/g;
  var upperCaseLetters = /[A-Z]/g;
  var numbers = /[0-9]/g;

  if (name.value.length == 0) {
    alert('Please fill in username');

  } else if (pw.value.length == 0) {
    alert('Please fill in password');

  } else if (name.value.length == 0 && pw.value.length == 0) {
    alert('Please fill in email and password');

  } else if (pw.value.length > 8) {
    alert('Max of 8');

  } else if (!pw.value.match(numbers)) {
    alert('please add 1 number');

  } else if (!pw.value.match(upperCaseLetters)) {
    alert('please add 1 uppercase letter');

  } else if (!pw.value.match(lowerCaseLetters)) {
    alert('please add 1 lowercase letter');

 
  } else if (!name.value.match(upperCaseLetters)) {
    alert('please add 1 uppercase letter');

  } else if (!name.value.match(lowerCaseLetters)) {
    alert('please add 1 lowercase letter');


  } else {
    localStorage.setItem('name', name.value);
    localStorage.setItem('pw', pw.value);
    alert('Your account has been created');
  }
}

//checking
function check() {
  var storedName = localStorage.getItem('name');
  var storedPw = localStorage.getItem('pw');

  var userName = document.getElementById('userName');
  var userPw = document.getElementById('userPw');
  var userRemember = document.getElementById("rememberMe");

  if (userName.value == storedName && userPw.value == storedPw) {
    alert('You are logged in.');
  } else {
    alert('Error on login');
  }
}